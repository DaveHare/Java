
abstract class AbstraktRute implements Rute{
public int posisjon;
	public AbstraktRute(int posisjon) {
		this.posisjon=posisjon;
		
	}
	public int getPosisjon(){
		return posisjon;
	}
	
	public void flyttHit(Spiller spilleren){
		
	}

}
