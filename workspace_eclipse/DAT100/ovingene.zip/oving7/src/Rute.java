
public interface Rute {

	public void flyttHit(Spiller spilleren);
	
}
