
public class arrayTest {

//	public arrayTest() {
//		// TODO Auto-generated constructor stub
//	}

	public static void main(String[] args) {
		

	}

}
