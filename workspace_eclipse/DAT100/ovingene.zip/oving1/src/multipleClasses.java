
public class multipleClasses {
	
	public static void main(String args[]){
		
		fallendeObjekt2  henteKlasse= new fallendeObjekt2();
		henteKlasse.programMetode();
	}

}
